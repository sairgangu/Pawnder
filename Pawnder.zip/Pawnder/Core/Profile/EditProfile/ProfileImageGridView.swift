////
////  ProfileImageGridView.swift
////  Pawnder
////
////  Created by Sai Gangu on 12/22/24.
////
//
//import SwiftUI
//
//struct ProfileImageGridView: View {
//    let user: User
//    
//    var body: some View {
//        LazyVGrid(columns: columns ) {
//            ForEach(0 ..<6) {index in
//                
//            }
//        }
//    }
//}
//
//private extension ProfileImageGridView {
//    private var columns: [GridItem]  {
//        [
//            .init(.flexible()),
//            .init(.flexible()),
//            .init(.flexible())
//        ]
//    }
//}
//#Preview {
//    ProfileImageGridView(user: MockData.users[0])
//}
