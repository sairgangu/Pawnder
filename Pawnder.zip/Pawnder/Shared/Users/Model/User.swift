//
//  User.swift
//  Pawnder
//
//  Created by Sai Gangu on 11/26/24.
//

import Foundation


struct User: Identifiable {
    
    let id: String
    let name: String
    var profileImageURL: String

    
    
    
    
    
}
