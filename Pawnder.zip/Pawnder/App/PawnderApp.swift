//
//  PawnderApp.swift
//  Pawnder
//
//  Created by Sai Gangu on 11/24/24.
//

import SwiftUI

@main
struct PawnderApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
